package projectt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {
    
    /**
     * Load all initial data from CSV files at application startup
     */
    public static void loadAllData() {
        System.out.println("Loading initial data from CSV files...");
        
        loadProductsCSV("products.csv");
        loadCustomersCSV("customers.csv");
        loadReviewsCSV("reviews.csv");
        loadOrdersCSV("orders.csv");
        
        System.out.println(" All data loaded successfully!");
    }

    // ---- Products CSV Loader ----
    public static void loadProductsCSV(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.toLowerCase().contains("product")) {
                    first = false;
                    continue; // Skip header
                }
                String[] t = line.split(",", -1);
                if (t.length < 4) continue;
                
                int id = Integer.parseInt(t[0].trim());
                String name = t[1].trim();
                double price = Double.parseDouble(t[2].trim());
                int stock = Integer.parseInt(t[3].trim());

                if (Main.products.empty()) {
                    Main.products.insert(new Product(id, name, price, stock));
                } else {
                    Main.products.findFirst();
                    Main.products.insert(new Product(id, name, price, stock));
                }
               
            }
            System.out.println("Products data loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error reading products CSV: " + e.getMessage());
        } 
    }

    // ---- Reviews CSV Loader ----
    public static void loadReviewsCSV(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.toLowerCase().contains("review")) {
                    first = false;
                    continue; // Skip header
                }
                String[] t = line.split(",", -1);
                if (t.length < 5) continue;
                
                int rid = Integer.parseInt(t[0].trim());
                int pid = Integer.parseInt(t[1].trim());
                int cid = Integer.parseInt(t[2].trim());
                int rate = Integer.parseInt(t[3].trim());
                String comment = t[4].trim();

                if (Main.reviews.empty()) {
                    Main.reviews.insert(new Review(rid, pid, cid, rate, comment));
                } else {
                    Main.reviews.findFirst();
                    Main.reviews.insert(new Review(rid, pid, cid, rate, comment));
                }
            }
            System.out.println("Reviews data loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error reading reviews CSV: " + e.getMessage());
        } 
    }

    // ---- Customers CSV Loader ----
    public static void loadCustomersCSV(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.toLowerCase().contains("customer")) {
                    first = false;
                    continue; // Skip header
                }
                String[] data = line.split(",", -1);
                if (data.length < 3) continue;
                
                int customerId = Integer.parseInt(data[0].trim());
                String name = data[1].trim();
                String email = data[2].trim();
                
                Customers c = new Customers(customerId, name, email);
                
                if (Customers.customers.empty()) {
                    Customers.customers.insert(c);
                } else {
                    Customers.customers.findFirst();
                    Customers.customers.insert(c);
                }
            }
            System.out.println(" Customers data loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error reading customers CSV: " + e.getMessage());
        }
    }

    // ---- Order CSV Loader ----
    public static void loadOrdersCSV(String path) {
    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
        String line;
        boolean first = true;

        while ((line = br.readLine()) != null) {
            if (first) {
                if (line.toLowerCase().contains("order")) {
                    first = false;
                    continue;
                }
                first = false;
            }

            if (line.trim().isEmpty()) continue;

            String[] t = line.split(",", -1);
            if (t.length < 6) continue;

            int orderId = Integer.parseInt(t[0].trim());
            int customerId = Integer.parseInt(t[1].trim());

            String rawProducts = t[2].trim();
            rawProducts = rawProducts.replace("\"", "");       
            String[] pTokens = rawProducts.split(";");
            Integer[] pids = new Integer[pTokens.length];
            for (int i = 0; i < pTokens.length; i++) {
                pids[i] = Integer.parseInt(pTokens[i].trim());
            }

            double totalPrice = Double.parseDouble(t[3].trim());

            String dateStr = t[4].trim();
            String isoDateStr;
            try {
                java.time.format.DateTimeFormatter f = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
                java.time.LocalDate d = java.time.LocalDate.parse(dateStr, f);
                isoDateStr = d.toString(); // ISO: yyyy-MM-dd
            } catch (Exception e) {
                isoDateStr = dateStr;
            }

            String status = t[5].trim();

            Order o = new Order(orderId, customerId, pids, totalPrice, isoDateStr, status);

            if (Main.orders.empty()) {
                Main.orders.insert(o);
            } else {
                Main.orders.findFirst();
                Main.orders.insert(o);
            }
        }

        System.out.println("Orders data loaded successfully!");
    } catch (IOException e) {
        System.out.println("Error reading orders CSV: " + e.getMessage());
    }
}
    
   
}