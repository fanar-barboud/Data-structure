package projectt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * Team Skeleton Main - Products & Reviews: implemented - Customers & Orders:
 * TODO placeholders
 */
public class Main {

	// ------------------------ Data Stores ------------------------
	// Ready implemented parts
	static LinkedList<Product> products = new LinkedList<>();
	static LinkedList<Review> reviews = new LinkedList<>();

	// TODO
	static LinkedList<Object> customers = new LinkedList<>(); // TODO: change to LinkedList<Customers>
	static LinkedList<Object> orders = new LinkedList<>(); // TODO: change to LinkedList<Orders>

	static final Scanner in = new Scanner(System.in);

	// ======================== CSV LOADERS ========================

	// ---- Products (implemented) ----
	static void loadProductsCSV(String path) {
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			String line;
			boolean first = true;
			while ((line = br.readLine()) != null) {
				if (first && line.toLowerCase().contains("product")) {
					first = false;
					continue;
				}
				String[] t = line.split(",", -1);
				if (t.length < 4)
					continue;
				int id = Integer.parseInt(t[0].trim());
				String name = t[1].trim();
				double price = Double.parseDouble(t[2].trim());
				int stock = Integer.parseInt(t[3].trim());

				if (products.empty())
					products.insert(new Product(id, name, price, stock));
				else {
					products.findFirst();
					products.insert(new Product(id, name, price, stock));
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading products CSV: " + e.getMessage());
		}
	}

	// ---- Reviews (implemented) ----
	static void loadReviewsCSV(String path) {
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			String line;
			boolean first = true;
			while ((line = br.readLine()) != null) {
				if (first && line.toLowerCase().contains("review")) {
					first = false;
					continue;
				}
				String[] t = line.split(",", -1);
				if (t.length < 5)
					continue;
				int rid = Integer.parseInt(t[0].trim());
				int pid = Integer.parseInt(t[1].trim());
				int cid = Integer.parseInt(t[2].trim());
				int rate = Integer.parseInt(t[3].trim());
				String comment = t[4].trim();

				if (reviews.empty())
					reviews.insert(new Review(rid, pid, cid, rate, comment));
				else {
					reviews.findFirst();
					reviews.insert(new Review(rid, pid, cid, rate, comment));
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading reviews CSV: " + e.getMessage());
		}
	}

	// ---- Customers (placeholder) ----
	static void loadCustomersCSV(String path) {
		// TODO
	}

	// ---- Orders (placeholder) ----
	static void loadOrdersCSV(String path) {
		// TODO
	}

	// ---- Cross-link reviews to their Product (implemented) ----
	// Assumes: products is LinkedList<Product>, reviews is LinkedList<Review>
	static void attachReviewsToProduct() {
		if (products.empty() || reviews.empty())
			return;

		products.findFirst();
		do {
			Product prod = products.retrieve();
			if (prod != null) {
				// For each product, walk all reviews and attach matching ones
				reviews.findFirst();
				do {
					Review r = reviews.retrieve();
					if (r != null && r.getProductId() == prod.getProductId()) {
						prod.addReview(r); // add the Review object, not an id
					}
					if (reviews.last())
						break; // checked the last review
					reviews.findNext();
				} while (true);
			}

			if (products.last())
				break; // checked the last product
			products.findNext();
		} while (true);
	}

	// ======================== PRODUCTS (Item 1) ========================

	static Product findProductById(int id) {
		if (products.empty())
			return null;

		products.findFirst();
		while (!products.last()) {
			if (products.retrieve().getProductId() == id)
				return products.retrieve();
			products.findNext();
		}
		if (products.retrieve().getProductId() == id)
			return products.retrieve();
		return null;
	}

	static Product findProductByName(String name) {
		if (products.empty())
			return null;

		products.findFirst();
		while (!products.last()) {
			if (products.retrieve().getName().equalsIgnoreCase(name))
				return products.retrieve();
			products.findNext();
		}
		if (products.retrieve().getName().equalsIgnoreCase(name))
			return products.retrieve();
		return null;
	}

	static void listOutOfStock() {
		if (products.empty()) {
			System.out.println("No products.");
			return;
		}

		System.out.println("Out-of-stock products:");
		boolean any = false;
		products.findFirst();
		while (!products.last()) {
			if (products.retrieve().getStock() == 0) {
				System.out.println(products.retrieve());
				any = true;
			}
			products.findNext();
		}
		if (products.retrieve().getStock() == 0) {
			System.out.println(products.retrieve());
			any = true;
		}
		if (!any)
			System.out.println("All products are in stock!");
	}

	// ======================== REVIEWS (Item 4) ========================



	static void top3ProductsByAvg() {
	    if (products.empty()) {
	        System.out.println("No products.");
	        return;
	    }

	    Product b1 = null, b2 = null, b3 = null;
	    double a1 = -1, a2 = -1, a3 = -1;

	    products.findFirst();
	    do {
	        Product p = products.retrieve();
	        if (p != null) {
	            double a = p.getAverageRating(); 
	            if (a > a1) {
	                a3 = a2; b3 = b2;
	                a2 = a1; b2 = b1;
	                a1 = a;  b1 = p;
	            } else if (a > a2) {
	                a3 = a2; b3 = b2;
	                a2 = a;  b2 = p;
	            } else if (a > a3) {
	                a3 = a;  b3 = p;
	            }
	        }
	        if (products.last()) break;
	        products.findNext();
	    } while (true);

	    System.out.println("Top products by average rating:");
	    int rank = 1;
	    if (b1 != null) { System.out.println(rank + ") " + b1.getProductId() + " " + b1.getName() + " avg=" + a1); rank++; }
	    if (b2 != null) { System.out.println(rank + ") " + b2.getProductId() + " " + b2.getName() + " avg=" + a2); rank++; }
	    if (b3 != null) { System.out.println(rank + ") " + b3.getProductId() + " " + b3.getName() + " avg=" + a3); }
	}


	// ======================== MENUS ========================


	// -------- Customers (TODO skeleton) --------
	static void customersMenu() {
		System.out.println("\n[Customers]");
		System.out.println("1) Load customers from CSV");
		System.out.println("2) Add customer");
		System.out.println("3) Update customer");
		System.out.println("4) Find customer by ID");
		System.out.println("5) List all customers");
		System.out.println("?) ##Any other needed options can be added, the above are sample options.");
		System.out.println("6) Back");
		System.out.print("Choice: ");
		int c = readInt();

		switch (c) {
		case 1:
			System.out.println("TODO: implement loadCustomersCSV(\"customers.csv\")");
			// loadCustomersCSV("customers.csv");
			break;
		case 2:
			System.out.println("TODO: implement add-customer (insert into LinkedList<Customers>)");
			break;
		case 3:
			System.out.println("TODO: implement update-customer fields");
			break;
		case 4:
			System.out.println("TODO: implement linear search by customerId");
			break;
		case 5:
			System.out.println("TODO: iterate with cursor and print all customers");
			break;
		default:
			break;
		}
	}

	// -------- Orders (TODO skeleton) --------
	static void ordersMenu() {
		System.out.println("\n[Orders]");
		System.out.println("1) Load orders from CSV");
		System.out.println("2) Add order");
		System.out.println("3) Update order");
		System.out.println("4) Find orders by customer ID");
		System.out.println("5) Find orders by product ID");
		System.out.println("?) ##Any other needed options can be added, the above are sample options.");
		System.out.println("6) Back");
		System.out.print("Choice: ");
		int c = readInt();

		switch (c) {
		case 1:
			System.out.println("TODO: implement loadOrdersCSV(\"orders.csv\")");
			// loadOrdersCSV("orders.csv");
			break;
		case 2:
			System.out.println("TODO: implement add-order and stock checks");
			break;
		case 3:
			System.out.println("TODO: implement update-order fields");
			break;
		case 4:
			System.out.println("TODO: linear scan orders by customerId");
			break;
		case 5:
			System.out.println("TODO: linear scan orders by productId");
			break;
		default:
			break;
		}
	}

	// ======================== MAIN ========================

	public static void main(String[] args) {
		loadProductsCSV("products.csv");
		loadReviewsCSV("reviews.csv");
		// loadCustomersCSV("customers.csv"); // TODO: when ready
		// loadOrdersCSV("orders.csv"); // TODO: when ready

		attachReviewsToProduct();

		int choice;
		do {
			System.out.println("\n==== MAIN MENU ====");
			System.out.println("1) Product");
			System.out.println("2) Customers (TODO)");
			System.out.println("3) Orders (TODO)");
			System.out.println("4) Reviews");
			System.out.println("5) Exit");
			System.out.print("Choice: ");
			choice = readInt();

			switch (choice) {
			case 1:
				System.out.println("\n[Product]"); // Product menu
				System.out.println("1) Add product");
				System.out.println("2) Update product");
				System.out.println("3) Remove product");
				System.out.println("4) Search by ID");
				System.out.println("5) Search by name");
				System.out.println("6) List out-of-stock");
				System.out.println("7) Back");
				System.out.print("Choice: ");
				int c = readInt();

				switch (c) {
				case 1: {
					int id = nextProductId();
					System.out.print("enter product name:");
					String name = in.next();
					System.out.print("enter product price:");
					double price = in.nextDouble();
					System.out.print("enter product stock:");
					int stock = in.nextInt();
					products.insert(new Product(id, name, price, stock));
					System.out.println("Added.");
					break;
				}
				case 2: {
					System.out.print("Enter product ID to update: ");
					int id = readInt();
					Product p = findProductById(id);
					if (p == null) {
						System.out.println("Not found.");
						break;
					}
					System.out.print("new name: ");
					in.nextLine();
					p.setName(in.nextLine());
					System.out.print("new price: ");
					p.setPrice(in.nextDouble());
					System.out.print("new stock: ");
					p.setStock(in.nextInt());
					System.out.println("Updated.");
					break;
				}
				case 3: {
					System.out.print("Enter product ID to remove: ");
					int id = readInt();
					Product p = findProductById(id);
					if (p == null)
						System.out.println("Not found.");
					else {
						p.setStock(0);
						System.out.println("Stock set to 0.");
					}
					break;
				}
				case 4: {
					System.out.print("Enter product ID to search: ");
					int id = readInt();
					Product p = findProductById(id);
					System.out.println((p == null) ? "Not found." : p.toString());
					break;
				}
				case 5: {
					System.out.print("name: ");
					String name = in.next();
					Product p = findProductByName(name);
					System.out.println((p == null) ? "Not found." : p.toString());
					break;
				}
				case 6:
					listOutOfStock();
					break;
				default:
					break;
				}
				break;
			case 2:
				customersMenu();
				break;
			case 3:
				ordersMenu();
				break;
			case 4:
				System.out.println("\n[Reviews]"); // =========Reviews Menu=========
				System.out.println("1) Add review");
				System.out.println("2) Edit review");
				System.out.println("3) Average rating for a product");
				System.out.println("4) Top-3 products by avg rating");
				System.out.println("5) Back");
				System.out.print("Choice: ");
				int c4 = readInt();

				switch (c4) {
				case 1: {
					int rid = nextReviewId();
					System.out.print("Enter product ID:");

					int pid = in.nextInt();
					System.out.print("Enter customer ID:");
					int cid = in.nextInt();
					System.out.print("Enter rating (1-5):");
					int rating = in.nextInt();
					System.out.print("Enter comment:");
					in.nextLine();
					String comment = in.nextLine();

					Product p = findProductById(pid);
					if (p != null) {
						Review r = new Review(rid, pid, cid, rating, comment);
						reviews.insert(r);
						p.addReview(r);
						System.out.println("Review added.");
						break;
					}
				}
				case 2: {
					System.out.print("Enter reviewId to edit: ");
					int rid = readInt();
					
					if (reviews.empty()) {
						System.out.println("No reviews.");
						break;
					}
					
					reviews.findFirst();
					while(!reviews.last()) {
						if (reviews.retrieve().getReviewId() == rid) {
							System.out.print("new rating (1..5): ");
							int newRating = in.nextInt();
							System.out.print("new comment: ");
							in.nextLine();
							String newComment = in.nextLine();
							reviews.retrieve().setRating(newRating);
							reviews.retrieve().setComment(newComment);
							System.out.println("Review has been updated.");
							break;
						}
							reviews.findNext();
					}
						if (reviews.retrieve().getReviewId() == rid) {
							System.out.print("new rating (1..5): ");
							int newRating = in.nextInt();
							System.out.print("new comment: ");
							String newComment = in.nextLine();
							reviews.retrieve().setRating(newRating);
							reviews.retrieve().setComment(newComment);
							System.out.println("Review has been updated.");
						}
					break;
				}
				case 3: {
					System.out.print("Enter a productId: ");
					int pid = readInt();
					Product product = findProductById(pid);
					System.out.println("Average rating = " + product.getAverageRating());
					break;
				}
				case 4:
					top3ProductsByAvg();
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
		} while (choice != 5);

		System.out.println("Bye.");
	}

	// Small helper to avoid Scanner newline pitfalls
	private static int readInt() {
		while (!in.hasNextInt()) {
			in.next();
		}
		return in.nextInt();
	}
	
	private static int nextReviewId() {
	    if (reviews.empty()) return 1;

	    int max = 0;
	    reviews.findFirst();
	    do {
	        Review r = reviews.retrieve();
	        if (r != null && r.getReviewId() > max) {
	            max = r.getReviewId();
	        }
	        if (reviews.last()) break;
	        reviews.findNext();
	    } while (true);

	    return max + 1;
	}
	
	private static int nextProductId() {
	    if (products.empty()) return 1;

	    int max = 0;
	    products.findFirst();
	    do {
	        Product p = products.retrieve();
	        if (p != null && p.getProductId() > max) {
	            max = p.getProductId();
	        }
	        if (products.last()) break;
	        products.findNext();
	    } while (true);

	    return max + 1;
	}
}
