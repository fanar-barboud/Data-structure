package projectt;

import java.util.Scanner;

/**
 * Team Skeleton Main - Products & Reviews: implemented - Customers & Orders:
 * TODO placeholders
 */
public class Main {

	// ------------------------ Data Stores ------------------------
	// Ready implemented parts
	static LinkedList<Product> products = new LinkedList<>();
	static LinkedList<Review> reviews = new LinkedList<>();
	static LinkedList<Customers> customers = new LinkedList<>();
	static LinkedList<Order> orders = new LinkedList<>();

	static final Scanner in = new Scanner(System.in);

	// ======================== MENUS ========================

	// -------- Orders (TODO skeleton) --------
	static void ordersMenu() {
		System.out.println("\n[Orders]");
		System.out.println("1) Load orders from CSV");
		System.out.println("2) Add order");
		System.out.println("3) Update order");
		System.out.println("4) Find orders by customer ID");
		System.out.println("5) Find orders by product ID");
		System.out.println("?) ##Any other needed options can be added, the above are sample options.");
		System.out.println("6) Back");
		System.out.print("Choice: ");
		int c = readInt();

		switch (c) {
		case 1:
			System.out.println("TODO: implement loadOrdersCSV(\"orders.csv\")");
			// loadOrdersCSV("orders.csv");
			break;
		case 2:
			System.out.println("TODO: implement add-order and stock checks");
			break;
		case 3:
			System.out.println("TODO: implement update-order fields");
			break;
		case 4:
			System.out.println("TODO: linear scan orders by customerId");
			break;
		case 5:
			System.out.println("TODO: linear scan orders by productId");
			break;
		default:
			break;
		}
	}

	// ======================== MAIN ========================

	public static void main(String[] args) {
		CSVReader.loadAllData();
		customers = Customers.customers; // binding

		Product.attachReviewsToProducts(products, reviews);

		int choice;
		do {
			System.out.println("\n==== MAIN MENU ====");
			System.out.println("1) Product");
			System.out.println("2) Customers");
			System.out.println("3) Orders");
			System.out.println("4) Reviews");
			System.out.println("5) Exit");
			System.out.print("Choice: ");
			choice = readInt();

			switch (choice) {
			case 1:
				System.out.println("\n[Product]"); // Product menu
				System.out.println("1) Add product");
				System.out.println("2) Update product");
				System.out.println("3) Remove product");
				System.out.println("4) Search by ID");
				System.out.println("5) Search by name");
				System.out.println("6) List out-of-stock");
				System.out.println("7) Common products reviewed by two customers (avg > 4.0)");
				System.out.println("8) Back");
				System.out.print("Choice: ");
				int c = readInt();

				switch (c) {
				case 1: {
					int id = nextProductId();
					System.out.print("enter product name:");
					in.nextLine();
					String name = in.nextLine();
					System.out.print("enter product price:");
					double price = in.nextDouble();
					System.out.print("enter product stock:");
					int stock = in.nextInt();
					products.insert(new Product(id, name, price, stock));
					System.out.println("Added.");
					break;
				}
				case 2: {
					System.out.print("Enter product ID to update: ");
					int id = readInt();
					Product p = Product.findProductById(products, id);
					if (p == null) {
						System.out.println("Product not found.");
						break;
					}
					System.out.print("new name: ");
					in.nextLine();
					p.setName(in.nextLine());
					System.out.print("new price: ");
					p.setPrice(in.nextDouble());
					System.out.print("new stock: ");
					p.setStock(in.nextInt());
					System.out.println("Updated.");
					break;
				}
				case 3: {
					System.out.print("Enter product ID to remove: ");
					int id = readInt();

					boolean removedProduct = Product.removeById(products, id);

					if (!removedProduct) {
						System.out.println("Product not found.");
						break;
					}

					// all global reviews for this product only if product was removed
					int removedReviews = Review.removeAllByProductId(reviews, id);

					System.out.println("Product removed from list.");
					System.out.println("Also removed " + removedReviews + " review(s) linked to this product.");
					break;
				}
				case 4: {
					System.out.print("Enter product ID to search: ");
					int id = readInt();
					Product p = Product.findProductById(products, id);
					System.out.println((p == null) ? "Product not found." : p.toString());
					break;
				}
				case 5: {
					System.out.print("name: ");
					in.nextLine();
					String name = in.nextLine();
					Product p = Product.findProductByName(products, name);
					System.out.println((p == null) ? "Product not found" : p.toString());
					break;
				}
				case 6:
					Product.listOutOfStock(products);
					break;
				case 7: 
					System.out.print("Enter first customer ID: ");
					int ca = readInt();
					System.out.print("Enter second customer ID: ");
					int cb = readInt();
					if (!customerExists(ca)) {
						System.out.println("First customer ID not found.");
						break;
					}
					if (!customerExists(cb)) {
						System.out.println("Second customer ID not found.");
						break;
					}

					// print the common products with avg > 4.0
					Review.printCommonHighRatedProducts(products, reviews, ca, cb);
					break;
				
				default:
					System.out.println("Invalid option!");
					break;
				}
				break;
			case 2:
				Customers api = new Customers();
				int c2;
				do {
					System.out.println("\n==== CUSTOMERS MENU ====");
					System.out.println("1) Register new customer");
					System.out.println("2) Search customer by ID");
					System.out.println("3) List all customers");
					System.out.println("4) Place new order for a customer");
					System.out.println("5) View orders history for a customer");
					System.out.println("6) Remove an order for a customer");
					System.out.println("7) Back");
					System.out.print("Choice: ");

					c2 = readInt();
					int id;
					switch (c2) {

					case 1:
						System.out.print("Enter Customer ID: ");
						id = in.nextInt();
						while (api.searchById(id)) {
							System.out.print("ID already exists, please enter another one: ");
							id = in.nextInt();
						}
						in.nextLine();
						System.out.print("Enter Customer Name: ");
						String fullName = in.nextLine();
						System.out.print("Enter Customer Email: ");
						String mail = in.nextLine();
						api.registerCustomer(id, fullName, mail);
						break;

					case 2:
						System.out.print("Enter Customer ID to search: ");
						id = in.nextInt();
						in.nextLine();
						boolean found = api.searchById(id);
						System.out.println(found ? "Customer exists in system." : "Customer not found.");
						break;

					case 3:
						api.displayAllCustomers();
						break;
					case 4:
						System.out.print("Enter Customer ID to place order: ");
						id = in.nextInt();
						api.placeOrder(id);
						break;
					case 5:
						System.out.print("Enter Customer ID to show orders: ");
						id = in.nextInt();
						api.showOrdersHistory(id);
						break;
					case 6:
						System.out.print("Enter Order ID to remove: ");
						int orderId = in.nextInt();
						boolean removed = api.RemoveOrder(orderId);
						System.out.println(removed ? "Order removed successfully!" : "Order not found!");
						break;
					case 7:
						System.out.println("Returning to Main Menu...");
						break;
					default:
						System.out.println("Invalid choice!");
					}
				} while (c2 != 7);
				break;
			case 3:
//				ordersMenu();
				break;
			case 4:
				System.out.println("\n[Reviews]"); // =========Reviews Menu=========
				System.out.println("1) Add review");
				System.out.println("2) Edit review");
				System.out.println("3) Average rating for a product");
				System.out.println("4) Top-3 products by avg rating");
				System.out.println("5) Back");
				System.out.print("Choice: ");
				int c4 = readInt();

				switch (c4) {
				case 1: {
					int rid = nextReviewId();
					System.out.print("Enter product ID:");
					int pid = in.nextInt();

					if (!Product.exists(products, pid)) { // check if product ID exists in products list
						System.out.println("Product ID not found.");
						break;
					}

					System.out.print("Enter customer ID:");
					int cid = in.nextInt();

					if (!customerExists(cid)) { // check if customer id exists in customers list
						System.out.println("Customer ID not found. Please add the customer first.");
						break;
					}

					if (Review.hasCustomerReviewedProduct(reviews, cid, pid)) {// customer can review a product only
																				// once.
						System.out.println("This customer already reviewed this product. Use 'Edit review' instead.");
						break;
					}

					System.out.print("Enter rating (1-5):");
					int rating = in.nextInt();

					if (!Review.isRatingValid(rating)) {// validates rating
						System.out.println("Invalid rating. Must be 1..5.");
						break;
					}

					System.out.print("Enter comment:");
					in.nextLine();
					String comment = in.nextLine();

					Product p = Product.findProductById(products, pid);
					if (p != null) {
						Review r = new Review(rid, pid, cid, rating, comment);
						reviews.insert(r);
						p.addReview(r);
						System.out.println("Review added.");
						break;
					}
					break;
				}
				case 2: {
					System.out.print("Enter reviewId to edit: ");
					int rid = readInt();

					Review existing = Review.findById(reviews, rid);
					if (existing == null) {
						System.out.println("Review not found.");
						break;
					}

					System.out.print("new rating (1..5): ");
					int newRating = readInt();
					if (!Review.isRatingValid(newRating)) {
						System.out.println("Invalid rating. Must be 1..5.");
						break;
					}

					System.out.print("new comment: ");
					in.nextLine();
					String newComment = in.nextLine();

					boolean ok = Review.updateRatingAndComment(reviews, rid, newRating, newComment);
					System.out.println(ok ? "Review has been updated." : "Update failed.");
					break;
				}
				case 3: {
					System.out.print("Enter a productId: ");
					int pid = readInt();

					if (!Product.exists(products, pid)) { // check if product ID exists in products list
						System.out.println("Product ID not found.");
						break;
					}

					Product product = Product.findProductById(products, pid);
					System.out.println("Average rating = " + product.getAverageRating());
					break;
				}
				case 4:
					Product.top3ByAverage(products);
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
		} while (choice != 5);

		System.out.println("Goodbye!");
	}

	// ========================================================HELPER METHODS
	// Small helper to avoid Scanner newline pitfalls
	private static int readInt() {
		while (!in.hasNextInt()) {
			in.next();
		}
		return in.nextInt();
	}

	private static int nextReviewId() {
		if (reviews.empty())
			return 1;

		int max = 0;
		reviews.findFirst();
		do {
			Review r = reviews.retrieve();
			if (r != null && r.getReviewId() > max) {
				max = r.getReviewId();
			}
			if (reviews.last())
				break;
			reviews.findNext();
		} while (true);

		return max + 1;
	}

	private static int nextProductId() {
		if (products.empty())
			return 1;

		int max = 0;
		products.findFirst();
		do {
			Product p = products.retrieve();
			if (p != null && p.getProductId() > max) {
				max = p.getProductId();
			}
			if (products.last())
				break;
			products.findNext();
		} while (true);

		return max + 1;
	}

	public static boolean customerExists(int id) {
		if (customers == null || customers.empty())
			return false;

		customers.findFirst();
		do {
			Customers c = customers.retrieve();
			if (c != null && c.getCustomerId() == id)
				return true;
			if (customers.last())
				break;
			customers.findNext();
		} while (true);

		return false;
	}

}
