package projectt;

public class Product {
	private int productId;
	private String name;
	private double price;
	private int stock;
	private LinkedList<Review> reviews = new LinkedList<Review>();

	public Product(int productId, String name, double price, int stock) {
		this.productId = productId;
		this.name = name;
		this.price = price;
		this.stock = stock;
	}

	public Product() { // unparameterized constructor
		this.productId = 0;
		this.name = "";
		this.price = 0;
		this.stock = 0;
	}

	public void addStock(int s) {
		stock += s;
	}
	// safeguard for less than 0

	public void removeStock(int s) {
		if (stock != 0)
			stock -= s;
		else
			System.out.println("Stock is at 0.");
	}

	public void addReview(Review review) {
		
		if (review == null) {
			System.out.println("Cannot add null review.");
			return;
		}
		
		 if (reviews.empty()) {
		        reviews.insert(review);
		        return;
		    }
		
		//to insert review at last
		reviews.findFirst();
		while(!reviews.last() ) { 
			reviews.findNext();
		}
		reviews.insert(review);
	}

	public boolean removeReview(int reviewId) { //removes a review using ID
		if (!reviews.empty()) {
			reviews.findFirst();
			while (!reviews.last()) {
				if (reviews.retrieve().getReviewId() == reviewId) {
					reviews.remove();
					return true;
				} else
					reviews.findNext();
			}
			if (reviews.retrieve().getReviewId() == reviewId) {
				reviews.remove();
				return true;
			}
		}
		return false;
	}

	public LinkedList<Review> getReviews() {

		return reviews;
	}

	public double getAverageRating() {
	    if (reviews.empty()) return 0.0;

	    int sum = 0;
	    int count = 0;

	    reviews.findFirst();
	    do {
	        Review r = reviews.retrieve();
	        if (r != null) {
	            sum += r.getRating();
	            count++;
	        }
	        if (reviews.last()) break;   // we just processed the last node
	        reviews.findNext();
	    } while (true);

	    if (count == 0) return 0.0;
	    return (sum * 1.0) / count;
	}
// O(n)

	// ----------- Minimal getters/setters (as needed later) -----------

	public int getProductId() {
		return productId;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public int getStock() {
		return stock;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	// ----------- ToString method -----------
	@Override
	public String toString() {
	    String str = "Product {\n";
	    str += "  id: " + productId + ",\n";
	    str += "  name: \"" + name + "\",\n";
	    str += "  price: " + price + ",\n";
	    str += "  stock: " + stock + ",\n";

	    if (reviews.empty()) {
	        str += "  reviews: []\n";
	    } else {
	        str += "  reviews: [\n";
	        reviews.findFirst();
	        do {
	            Review r = reviews.retrieve();
	            str += "    ";
	            if (r != null) {
	                str += r.toString();
	            } else {
	                str += "null";
	            }

	            if (reviews.last()) {
	                str += "\n";
	                break;
	            }
	            str += ",\n";
	            reviews.findNext();
	        } while (true);
	        str += "  ]\n";
	    }

	    str += "}";
	    return str;
	}

}
