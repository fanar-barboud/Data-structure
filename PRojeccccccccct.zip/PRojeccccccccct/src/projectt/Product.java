package projectt;

public class Product {
	private int productId;
	private String name;
	private double price;
	private int stock;
	private LinkedList<Review> reviews ;

	public Product(int productId, String name, double price, int stock) {
		this.productId = productId;
		this.name = name;
		this.price = price;
		this.stock = stock;
		reviews = new LinkedList<Review>();
	}

	public Product() { // unparameterized constructor
		this.productId = 0;
		this.name = "";
		this.price = 0;
		this.stock = 0;
		reviews = null;
	}

	public void addStock(int s) {
		stock += s;
	}
	// safeguard for less than 0

	public void removeStock(int s) {
		if (stock != 0)
			stock -= s;
		else
			System.out.println("Stock is at 0.");
	}

	public void addReview(Review review) {
		
		if (review == null) {
			System.out.println("Cannot add null review.");
			return;
		}
		
		 if (reviews.empty()) {
		        reviews.insert(review);
		        return;
		    }
		
		//to insert review at last
		reviews.findFirst();
		while(!reviews.last() ) { 
			reviews.findNext();
		}
		reviews.insert(review);
	}

	public boolean removeReview(int reviewId) { //removes a review using ID
		if (!reviews.empty()) {
			reviews.findFirst();
			while (!reviews.last()) {
				if (reviews.retrieve().getReviewId() == reviewId) {
					reviews.remove();
					return true;
				} else
					reviews.findNext();
			}
			if (reviews.retrieve().getReviewId() == reviewId) {
				reviews.remove();
				return true;
			}
		}
		return false;
	}

	public LinkedList<Review> getReviews() {

		return reviews;
	}

	public double getAverageRating() {
	    if (reviews.empty()) return 0.0;

	    int sum = 0;
	    int count = 0;

	    reviews.findFirst();
	    do {
	        Review r = reviews.retrieve();
	        if (r != null) {
	            sum += r.getRating();
	            count++;
	        }
	        if (reviews.last()) break;   // we just processed the last node
	        reviews.findNext();
	    } while (true);

	    if (count == 0) return 0.0;
	    return (sum * 1.0) / count;
	}
// O(n)
	
	// Find by ID (cursor-style; checks last node)
	public static Product findProductById(LinkedList<Product> products, int id) {
	    if (products.empty()) return null;

	    products.findFirst();
	    do {
	        Product p = products.retrieve();
	        if (p != null && p.getProductId() == id) return p;

	        if (products.last()) break;
	        products.findNext();
	    } while (true);

	    return null;
	}

	// Find by name (case-insensitive)
	public static Product findProductByName(LinkedList<Product> products, String name) {
	    if (products.empty()) return null;

	    products.findFirst();
	    do {
	        Product p = products.retrieve();
	        if (p != null && p.getName().equalsIgnoreCase(name)) return p;

	        if (products.last()) break;
	        products.findNext();
	    } while (true);

	    return null;
	}
	
	public static void listOutOfStock(LinkedList<Product> products) {
	    if (products.empty()) {
	        System.out.println("No products.");
	        return;
	    }

	    System.out.println("Out-of-stock products:");
	    boolean any = false;

	    products.findFirst();
	    do {
	        Product p = products.retrieve();
	        if (p != null && p.getStock() <= 0) {
	            System.out.println(p);
	            any = true;
	        }
	        if (products.last()) break;
	        products.findNext();
	    } while (true);

	    if (!any) System.out.println("All products are in stock!");
	}
	
	public static void top3ByAverage(LinkedList<Product> products) {
	    if (products.empty()) {
	        System.out.println("No products.");
	        return;
	    }

	    Product b1 = null, b2 = null, b3 = null;
	    double a1 = -1.0, a2 = -1.0, a3 = -1.0;

	    products.findFirst();
	    do {
	        Product p = products.retrieve();
	        if (p != null) {
	            double a = p.getAverageRating();
	            if (a > a1) { a3 = a2; b3 = b2; a2 = a1; b2 = b1; a1 = a; b1 = p; }
	            else if (a > a2) { a3 = a2; b3 = b2; a2 = a;  b2 = p; }
	            else if (a > a3) { a3 = a;  b3 = p; }
	        }
	        if (products.last()) break;
	        products.findNext();
	    } while (true);

	    System.out.println("Top products by average rating:");
	    int rank = 1;
	    if (b1 != null) { System.out.println(rank + ") " + b1.getProductId() + " " + b1.getName() + " avg=" + a1); rank++; }
	    if (b2 != null) { System.out.println(rank + ") " + b2.getProductId() + " " + b2.getName() + " avg=" + a2); rank++; }
	    if (b3 != null) { System.out.println(rank + ") " + b3.getProductId() + " " + b3.getName() + " avg=" + a3); }
	}

	
	// Link each Review to its Product.
	public static void attachReviewsToProducts(LinkedList<Product> products, LinkedList<Review> reviews) {
	    if (products.empty() || reviews.empty()) return;

	    products.findFirst();
	    do {
	        Product prod = products.retrieve();
	        if (prod != null) {
	            reviews.findFirst();
	            do {
	                Review r = reviews.retrieve();
	                if (r != null && r.getProductId() == prod.getProductId()) {
	                    prod.addReview(r); // attaches the Review object
	                }
	                if (reviews.last()) break;
	                reviews.findNext();
	            } while (true);
	        }
	        if (products.last()) break;
	        products.findNext();
	    } while (true);
	}


	// ----------- Minimal getters/setters (as needed later) -----------

	public int getProductId() {
		return productId;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public int getStock() {
		return stock;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	// ----------- ToString method -----------
	@Override
	public String toString() {
	    String str = "Product {\n";
	    str += "  id: " + productId + ",\n";
	    str += "  name: \"" + name + "\",\n";
	    str += "  price: " + price + ",\n";
	    str += "  stock: " + stock + ",\n";

	    if (reviews.empty()) {
	        str += "  reviews: []\n";
	    } else {
	        str += "  reviews: [\n";
	        reviews.findFirst();
	        do {
	            Review r = reviews.retrieve();
	            str += "    ";
	            if (r != null) {
	                str += r.toString();
	            } else {
	                str += "null";
	            }

	            if (reviews.last()) {
	                str += "\n";
	                break;
	            }
	            str += ",\n";
	            reviews.findNext();
	        } while (true);
	        str += "  ]\n";
	    }

	    str += "}";
	    return str;
	}

}
