package projectt;

public class Review {
	 	int reviewId;
	    int productID;
	    int customerID;
	    int rating;
	    String comment;

	    public Review() { //unparameterized constructor
	        this.reviewId = 0;
	        this.productID = 0;
	        this.customerID = 0;
	        this.rating = 0;
	        this.comment = "";
	    }

	    public Review(int reviewId, int product, int customer, int rating, String comment) { //must validate rating
	        this.reviewId = reviewId; 
	        this.productID = product;
	        this.customerID = customer;
	        this.rating = rating;
	        this.comment = comment;
	    }

	    public int getReviewId() {
	        return reviewId;
	    }

	    public void setReviewId(int reviewId) {
	        this.reviewId = reviewId;
	    }

	    public int getProductId() {
	        return productID;
	    }

	    public void setProduct(int product) {
	        this.productID = product;
	    }

	    public int getCustomer() {
	        return customerID;
	    }

	    public void setCustomer(int customer) {
	        this.customerID = customer;
	    }

	    public int getRating() {
	        return rating;
	    }

	    public void setRating(int rating) {
	        this.rating = rating;
	    }

	    public String getComment() {
	        return comment;
	    }

	    public void setComment(String comment) {
	        this.comment = comment;
	    }

	    @Override
	    public String toString() {
	        String str = "Review {\n";
	        str += "  id: " + reviewId + ",\n";
	        str += "  productId: " + productID + ",\n";
	        str += "  customerId: " + customerID + ",\n";
	        str += "  rating: " + rating + ",\n";
	        str += "  comment: ";
	        if (comment != null) {
	            str += "\"" + comment + "\"\n";
	        } else {
	            str += "null\n";
	        }
	        str += "}";
	        return str;
	    }

	    
	    
	    
	}