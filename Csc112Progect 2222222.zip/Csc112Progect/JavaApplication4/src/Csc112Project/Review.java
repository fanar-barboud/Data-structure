package Csc112Project;

public class Review {
	
		//ATTRIBUTES 
	    private  int reviewId;
	    private  int productID;
	    private  int customerID;
	    private  int rating;
	    private  String comment;

		//CONSTRUCTOR
	    public Review(int reviewId, int product, int customer, int rating, String comment) { //must validate rating
	        this.reviewId = reviewId; 
	        this.productID = product;
	        this.customerID = customer;
	        this.rating = rating;
	        this.comment = comment;
	    }

	    public int getReviewId() {
	        return reviewId;
	    }

	    public void setReviewId(int reviewId) {
	        this.reviewId = reviewId;
	    }

	    public int getProductId() {
	        return productID;
	    }

	    public void setProduct(int product) {
	        this.productID = product;
	    }

	    public int getCustomer() {
	        return customerID;
	    }

	    public void setCustomer(int customer) {
	        this.customerID = customer;
	    }

	    public int getRating() {
	        return rating;
	    }

	    public void setRating(int rating) {
	        this.rating = rating;
	    }

	    public String getComment() {
	        return comment;
	    }

	    public void setComment(String comment) {
	        this.comment = comment;
	    }

	    @Override
	    public String toString() {
	        String str = "Review {\n";
	        str += "  id: " + reviewId + ",\n";
	        str += "  productId: " + productID + ",\n";
	        str += "  customerId: " + customerID + ",\n";
	        str += "  rating: " + rating + ",\n";
	        str += "  comment: ";
	        if (comment != null) {
	            str += "\"" + comment + "\"\n";
	        } else {
	            str += "null\n";
	        }
	        str += "}";
	        return str;
	    }

	 // Validate rating range 1..5
	    public static boolean isRatingValid(int rating) {
	        return rating >= 1 && rating <= 5;
	    }

	    // Has this customer already reviewed this product?
	    public static boolean hasCustomerReviewedProduct(LinkedList<Review> allReviews, int customerId, int productId) {
	        if (allReviews == null || allReviews.empty()) return false;

	        allReviews.findFirst();
	        do {
	            Review r = allReviews.retrieve();
	            if (r != null && r.getCustomer() == customerId && r.getProductId() == productId) return true;
	            if (allReviews.last()) break;
	            allReviews.findNext();
	        } while (true);

	        return false;
	    }

	 // Find a review by id 
	    public static Review findById(LinkedList<Review> allReviews, int rid) {
	        if (allReviews == null || allReviews.empty()) return null;
	        allReviews.findFirst();
	        do {
	            Review r = allReviews.retrieve();
	            if (r != null && r.getReviewId() == rid) return r;
	            if (allReviews.last()) break;
	            allReviews.findNext();
	        } while (true);
	        return null;
	    }

	    // Update rating & comment with validation (returns true if updated)
	    public static boolean updateRatingAndComment(LinkedList<Review> allReviews,
	                                                int rid, int newRating, String newComment) {
	        Review r = findById(allReviews, rid);
	        if (r == null) return false;                  // not found
	        if (!isRatingValid(newRating)) return false;  // invalid rating 1..5
	        r.setRating(newRating);
	        r.setComment(newComment == null ? "" : newComment);
	        return true;
	    }

	    
	   

	 // Print common products reviewed by BOTH customers with global average > 4.0
	    public static void printCommonHighRatedProducts(LinkedList<Product> products,
	                                                    LinkedList<Review> allReviews,
	                                                    int cid1, int cid2) {
	        // 1) collect unique product IDs for each customer
	        LinkedList<Integer> ids1 = new LinkedList<>();
	        LinkedList<Integer> ids2 = new LinkedList<>();

	        if (!allReviews.empty()) {
	            allReviews.findFirst();
	            do {
	                Review r = allReviews.retrieve();
	                if (r != null) {
	                    if (r.getCustomer() == cid1) addUniqueInt(ids1, r.getProductId());
	                    if (r.getCustomer() == cid2) addUniqueInt(ids2, r.getProductId());
	                }
	                if (allReviews.last()) break;
	                allReviews.findNext();
	            } while (true);
	        }

	        // 2) intersection -> check avg > 4.0 using the global reviews list
	        LinkedList<Product> result = new LinkedList<>();
	        if (!ids1.empty()) {
	            ids1.findFirst();
	            do {
	                Integer pid = ids1.retrieve();
	                if (pid != null && containsInt(ids2, pid.intValue())) {
	                    double avg = averageForProduct(allReviews, pid.intValue());
	                    if (avg > 4.0) {
	                        Product p = Product.findProductById(products, pid.intValue());
	                        if (p != null) insertAtEnd(result, p);
	                    }
	                }
	                if (ids1.last()) break;
	                ids1.findNext();
	            } while (true);
	        }

	        // 3) print
	        if (result.empty()) {
	            System.out.println("No common products with average > 4.0.");
	            return;
	        }
	        System.out.println("Common products (avg > 4.0):");
	        result.findFirst();
	        do {
	            Product p = result.retrieve();
	            if (p != null) {
	                double avg = averageForProduct(allReviews, p.getProductId());
	                System.out.println(p.getProductId() + " | " + p.getName() + " | avg=" + avg);
	            }
	            if (result.last()) break;
	            result.findNext();
	        } while (true);
	    }


	    private static void addUniqueInt(LinkedList<Integer> list, int val) {
	        if (list == null) return;
	        if (!containsInt(list, val)) insertAtEnd(list, Integer.valueOf(val));
	    }

	    private static boolean containsInt(LinkedList<Integer> list, int val) {
	        if (list == null || list.empty()) return false;
	        list.findFirst();
	        do {
	            Integer x = list.retrieve();
	            if (x != null && x.intValue() == val) return true;
	            if (list.last()) break;
	            list.findNext();
	        } while (true);
	        return false;
	    }

	    private static <T> void insertAtEnd(LinkedList<T> list, T item) {
	        if (list.empty()) { list.insert(item); return; }
	        list.findFirst();
	        while (!list.last()) list.findNext();
	        list.insert(item);
	    }

	    private static double averageForProduct(LinkedList<Review> allReviews, int productId) {
	        if (allReviews == null || allReviews.empty()) return 0.0;
	        int sum = 0, count = 0;
	        allReviews.findFirst();
	        do {
	            Review r = allReviews.retrieve();
	            if (r != null && r.getProductId() == productId) { sum += r.getRating(); count++; }
	            if (allReviews.last()) break;
	            allReviews.findNext();
	        } while (true);
	        return (count == 0) ? 0.0 : ((double)sum / (double)count);
	    }

	    public static boolean removeById(LinkedList<Review> allReviews, int rid) {
	        if (allReviews == null || allReviews.empty()) return false;

	        allReviews.findFirst();
	        do {
	            Review r = allReviews.retrieve();
	            if (r != null && r.getReviewId() == rid) {
	                allReviews.remove();
	                return true;
	            }
	            if (allReviews.last()) break;
	            allReviews.findNext();
	        } while (true);

	        return false;
	    }

	    // Remove ALL reviews belonging to a given productId from the global list.
	    // Returns how many reviews were removed.
	    public static int removeAllByProductId(LinkedList<Review> allReviews, int productId) {
	        if (allReviews == null || allReviews.empty()) return 0;

	        // 1) Collect matching review IDs first (safe, no mutation while scanning)
	        LinkedList<Integer> toDelete = new LinkedList<>();
	        allReviews.findFirst();
	        do {
	            Review r = allReviews.retrieve();
	            if (r != null && r.getProductId() == productId) {
	                // append at end
	                if (toDelete.empty()) {
	                    toDelete.insert(Integer.valueOf(r.getReviewId()));
	                } else {
	                    toDelete.findFirst();
	                    while (!toDelete.last()) toDelete.findNext();
	                    toDelete.insert(Integer.valueOf(r.getReviewId()));
	                }
	            }
	            if (allReviews.last()) break;
	            allReviews.findNext();
	        } while (true);

	        // 2) Remove each by id
	        int removed = 0;
	        if (!toDelete.empty()) {
	            toDelete.findFirst();
	            do {
	                Integer rid = toDelete.retrieve();
	                if (rid != null && removeById(allReviews, rid.intValue())) removed++;
	                if (toDelete.last()) break;
	                toDelete.findNext();
	            } while (true);
	        }
	        return removed;
	    }
	    
	    
	    
	}