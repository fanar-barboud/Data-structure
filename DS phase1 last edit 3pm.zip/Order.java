/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fanar
 */
package com.mycompany.ds1;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;



public class Order {
    
    /* ATTRIBUTES */
    private int orderId;
    private int customerId;
    private LinkedList<Integer> products = new LinkedList<Integer>();
    private double totalPrice;
    private LocalDate date;
    private String status; // (pending, shipped, delivered, cancelled)
    
    /*CONSTRUCTORS */
    public Order() {
        this.orderId = 0;
        this.customerId = 0;
        this.totalPrice = 0.0;
        this.date = LocalDate.now();   // today's date
        this.status = "pending"; 
    }

    public Order(int orderId, int customerId, Integer[] productIds,double totalPrice, String date, String status) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.totalPrice = totalPrice;
        this.date = LocalDate.parse(date);
        this.status = status;

        for (int i = 0; i < productIds.length; i++) {
              products.insert(productIds[i]);
          }
    }
    
   /* SEARCH for a specific ORDER by its ID */
   public static Order searchOrder(LinkedList<Order> orders, int id) {

    if (orders == null || orders.empty()) {
        System.out.println(" No orders are currently available in the system.");
        return null;
    }

    orders.findFirst();
    while (true) {

        Order o = orders.retrieve();

        if (o.getOrderId() == id) {   
            return o;
        }

        if (orders.last()) break;     

        orders.findNext();            
    }

    System.out.println(" No order found with ID: " + id);
    return null;
}

    
 /* UPDATE an OREDER STATUS*/
    public static boolean updateOrderStatus(LinkedList<Order> orders, int id, String newStatus){
    if (orders.empty()) {

        System.out.println("️\nNo orders are currently available in the system.");

        return false;
    }

    orders.findFirst();
    while (true) {
        Order current = orders.retrieve();

        if (current.getOrderId() == id) {
            if ("cancelled".equalsIgnoreCase(current.getStatus())) {

                System.out.println("️\nCannot update: order " + id + " is already Cancelled.");

                return false;
            }
            current.setStatus(newStatus);


            return true;
        }

        if (orders.last()) break;
        orders.findNext();
    }

    System.out.println("\nNo order found with ID: " + id);

    return false;
}
    /*CANCEL an ORDER by its ID */
    public static boolean cancelOrder(LinkedList<Order> orders,int id) {
    if (orders.empty()) {

        System.out.println("️\nNo orders are currently available in the system.");
     
        return false;
    }

    orders.findFirst();
    while (true) {
        Order current = orders.retrieve();

        if (current.getOrderId() == id) {

            if ("cancelled".equalsIgnoreCase(current.getStatus())) {
                System.out.println("️\nOrder " + id + " was already cancelled.");
                return false; 
            }

            current.setStatus("cancelled");
            return true;
        }

        if (orders.last()) break;
        orders.findNext();
    }
 
    System.out.println("\nNo order found with ID: " + id);
    return false;
    }
    
    /* GET ORDERS BETTWEN TWO DATES */
    public static LinkedList<Order> allOrdersBetweenDates(LinkedList<Order> orders,String sDate, String eDate) {
        
    LinkedList<Order> ordersD = new LinkedList<>();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    LocalDate start = LocalDate.parse(sDate, formatter);
    LocalDate end = LocalDate.parse(eDate, formatter);

    if (orders.empty()) {
        System.out.println("️\nNo orders are currently available in the system.");
        return ordersD;
    }

    orders.findFirst();
    while (true) {
        Order current = orders.retrieve();
        LocalDate orderDate = current.getDate();

        if (!orderDate.isBefore(start) && !orderDate.isAfter(end)) {
            ordersD.insert(current);
            System.out.println(current);
        }

        if (orders.last()) break;
        orders.findNext();
    }

    return ordersD;
 }
    
    // ===================================================================================================
    
    
    /*public boolean removeProduct( Integer P)
    {
        if ( ! products.empty())
        {
            products.findFirst();
            while(! products.last())
            {
                if (products.retrieve() == P)
                {
                    products.remove();
                    return true;
                }
                else
                    products.findNext();
            }
            if (products.retrieve() == P)
            {
                products.remove();
                return true;
            }
        }
        return false;
    }*/
    
    
    
    
    public void createOrder(int orderId, int customerId, Integer[] productIds, double total, String date, String status) {

    this.orderId = orderId;
    this.customerId = customerId;
    this.totalPrice = total;
    this.date = LocalDate.parse(date);
    this.status = status;

    // Store product IDs in the LinkedList
    for (int i = 0; i < productIds.length; i++) {
        products.insert(productIds[i]);
    }
}

    
    /* SETTERS & GETTERS */
    public int getOrderId() {
        return orderId;
    }

    public int getcustomerId() {
        return customerId;
    }

    public LinkedList<Integer> getProducts() {
        return products;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getStatus() {
        return status;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public void setcustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setProducts(int pid) {
        this.products.insert(pid);
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void addProduct (Integer p )
    {
        products.insert(p);
    }
    
    
   /* public static void placeOrder(Customers c, Order o) {
    if (c == null || o == null) {
        System.out.println("Error placing order.");
        return;
    }

    c.getOrdersList().insert(o);   // Add to customer's list
    Main.orders.insert(o);         // Add to global list

    System.out.println("Order placed successfully for " + c.getName());
}

*/
   /*============ To Display Order Informaition ============*/
    @Override
    public String toString() {
       String orderInfo = "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    orderInfo += "Order Details\n";
    orderInfo += "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    orderInfo += "Order ID        : " + orderId + "\n";
    orderInfo += "Customer ID     : " + customerId + "\n";
    orderInfo += "Total Price     : " + totalPrice + "\n";
    orderInfo += "Date            : " + date + "\n";
    orderInfo += "Status          : " + status + "\n";
                   
    if (!products.empty()) {
        orderInfo += "Product IDs     : ";
        products.findFirst();
        while (true) {
            orderInfo += products.retrieve();
            if (products.last()) break;
            orderInfo += ", ";
            products.findNext();
        }
        orderInfo += "\n";
    } else {
        orderInfo += "Products List   : (none)\n";
    }

    orderInfo += "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    return orderInfo;
    }

}