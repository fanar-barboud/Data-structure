package com.mycompany.ds1;


import java.util.Scanner;

/**
 * Team Skeleton Main - Products & Reviews: implemented - Customers & Orders:
 * TODO placeholders
 */
public class Main {

// ------------------------ Data Stores ------------------------
// Ready implemented parts
static LinkedList<Product> products = new LinkedList<>();
static LinkedList<Review> reviews = new LinkedList<>();
static LinkedList<Customers> customers = new LinkedList<>();
static LinkedList<Order> orders = new LinkedList<>();

static final Scanner in = new Scanner(System.in);


public static void main(String[] args) {
CSVReader.loadAllData();

Product.attachReviewsToProducts(products, reviews);

int choice;
do {
    System.out.println("\n---------- Main Menu ----------");
    System.out.println("1) Product");
    System.out.println("2) Customers");
    System.out.println("3) Orders");
    System.out.println("4) Reviews");
    System.out.println("5) Exit");
    System.out.print("Choice: ");
    choice = readInt();

switch (choice) {
    
case 1:
    
    int c1;
    
    do{
    
    System.out.println("\n---------- Product Menu ----------"); 
    System.out.println("1) Add product");
    System.out.println("2) Update product");
    System.out.println("3) Remove product");
    System.out.println("4) Search by ID");
    System.out.println("5) Search by name");
    System.out.println("6) List out-of-stock");
    System.out.println("7) Common products reviewed by two customers (avg > 4.0)");
    System.out.println("8) Back");
    System.out.print("Choice: ");
    c1 = readInt();

	switch (c1) {
            
	case 1: {
	int id = nextProductId();
	System.out.print("enter product name:");
	in.nextLine();
	String name = in.nextLine();
	System.out.print("enter product price:");
	double price = readDouble();
	System.out.print("enter product stock:");
	int stock = readInt();
	products.insert(new Product(id, name, price, stock));
	System.out.println("Added.");
        
	break;
		}
        
	case 2: {
            
	System.out.print("Enter product ID to update: ");
	int id = readInt();
	Product p = Product.findProductById(products, id);
	if (p == null) {
	System.out.println("Product not found.");
        
	break;
	}
	System.out.print("new name: ");
	in.nextLine();
	p.setName(in.nextLine());
	System.out.print("new price: ");
	p.setPrice(readDouble());
	System.out.print("new stock: ");
	p.setStock(readInt());
	System.out.println("Updated.");
        
	break;
		}
        
	case 3: {
            
	System.out.print("Enter product ID to remove: ");
	int id = readInt();

	boolean removedProduct = Product.removeById(products, id);

	if (!removedProduct) {
	System.out.println("Product not found.");
        
	break;
                }

	int removedReviews = Review.removeAllByProductId(reviews, id);

	System.out.println("Product removed from list.");
	System.out.println("Also removed " + removedReviews + " review(s) linked to this product.");
        
	break;
		}
        
	case 4: {
            
	System.out.print("Enter product ID to search: ");
	int id = readInt();
	Product p = Product.findProductById(products, id);
	System.out.println((p == null) ? "Product not found." : p.toString());
        
	break;
		}
        
	case 5: {
            
	System.out.print("name: ");
	in.nextLine();
	String name = in.nextLine();
        
	Product p = Product.findProductByName(products, name);
	System.out.println((p == null) ? "Product not found" : p.toString());
        
	break;
        
		}
        
	case 6: {
            
	Product.listOutOfStock(products);
	break;
        
        }
        
	case 7: {
            
	System.out.print("Enter first customer ID: ");
	int ca = readInt();
        
	System.out.print("Enter second customer ID: ");
	int cb = readInt();
        
	if (!customerExists(ca)) {
	System.out.println("First customer ID not found.");
	break;
		}
        
	if (!customerExists(cb)) {
	System.out.println("Second customer ID not found.");
	break;
		}

	// print the common products with avg > 4.0
	Review.printCommonHighRatedProducts(products, reviews, ca, cb);
        
	break;
        
        }
        
        case 8:
            
        System.out.println("Back to Main Menu...");
        break;
        
	default:
	System.out.println("Invalid option!");
	break;
                    }
        
              }while(c1 != 8);
	break;
case 2:
    
    int c2;
    
    do {
        
    System.out.println("\n---------- Customer Menu ----------");
    System.out.println("1) Register new customer");
    System.out.println("2) Search customer by ID");
    System.out.println("3) List all customers");
    System.out.println("4) Place new order for a customer");
    System.out.println("5) View orders history for a customer");
    System.out.println("6) Remove an order for a customer");
    System.out.println("7) Back");
    System.out.print("Choice: ");
    c2 = readInt();
    
    //int id;
    
	switch (c2) {

	case 1:{
            
	System.out.print("Enter Customer ID: ");
	int id = readInt();
	while (Customers.searchById(id)) {
	System.out.print("ID already exists, please enter another one: ");
	id = readInt();
		}
        
	in.nextLine();
	System.out.print("Enter Customer Name: ");
	String fullName = in.nextLine();
	System.out.print("Enter Customer Email: ");
	String mail = in.nextLine();
	Customers.registerCustomer(id, fullName, mail);
        
	break;
        
        }
        
	case 2:{
            
	System.out.print("Enter Customer ID to search: ");
	int id = readInt();
	in.nextLine();
	boolean found = Customers.searchById(id);
        Customers c3 = Customers.findCustomerById(id);
        if (c3 != null) {
        System.out.println("Customer exists in system. " + c3.getName() + " found");
            } else {
        System.out.println("Customer" + c3.getName() + "  not found!!");
                     }

	break;
        
        }
        
	case 3:{
            
	Customers.displayAllCustomers();
	break;
        
                }
        
	case 4:{
						
        System.out.print("Enter Customer ID: ");
        int cid = readInt();

        Customers cust = Customers.findCustomerById(cid);
        if (cust == null) {
        System.out.println("Customer not found!");
        break;
                   }

        int oid = nextOrderId();  

        System.out.print("How many products? ");
        int count = readInt();

        Integer[] pids = new Integer[count];
        double total = 0;

        for (int i = 0; i < count; i++) {

        System.out.print("Enter product ID #" + (i + 1) + ": ");
        int pid = readInt();

        Product p = Product.findProductById(products, pid);

        if (p == null) {
        System.out.println("Product ID " + pid + " not found. Skipping it.");
        pids[i] = -1; 
        continue;
                  }

        if (p.getStock() <= 0) {
        System.out.println("Product " + p.getName() + " is OUT OF STOCK. Skipping it.");
        pids[i] = -1;
        continue;
                     }

        pids[i] = pid;

        total += p.getPrice();

        p.removeStock(1);
                                }

        String date = java.time.LocalDate.now().toString();
        String status = "pending";

        Order o = new Order();
        o.createOrder(oid, cid, pids, total, date, status);
        Customers.placeOrder(cust, o);

        System.out.println("Order created with ID: " + oid);
        
        break;
        
        }                            
                                            
	case 5:{
            
	System.out.print("Enter Customer ID to show orders: ");
	int id = readInt();
	if (!customerExists(id)) {
        System.out.println("Customer not found!!.");
        break;
                 }

        Customers.showOrdersHistory(id);
 
        break;
        
                }
        
	case 6:{
            
	System.out.print("Enter Customer ID: ");
        int custId  = readInt();

        if (!customerExists(custId)) {
        System.out.println("Customer not found!!.");
        break;
               }

        System.out.print("Enter Order ID to remove: ");
        int ordID = readInt();

        Customers.removeOrder(custId, ordID);
        
        break;
                }
        
	case 7:{
            
	System.out.println("Back to Main Menu...");
	break;
        
        }
        
	default:
	System.out.println("Invalid choice!");
        
        break;
        
	}
		} while (c2 != 7);
	break;
case 3:
    
    int c3 ;
    
    do{
    
    System.out.println("\n---------- Order Menu ----------");
    System.out.println("1) Search for an order");
    System.out.println("2) Update order status");
    System.out.println("3) Cancel order");
    System.out.println("4) Orders between two dates");
    System.out.println("5) Back");
    System.out.print("Choice: ");
    c3 = readInt();

	switch (c3) {
                    
        case 1:
        
        System.out.print("Enter Order ID to search: ");
        int oid = readInt();

        Order o = Order.searchOrder(orders, oid);   

        if (o != null) {
            System.out.println("\nOrder found:");
            System.out.println(o);                  
        }
        
        break;
     
        case 2:
        
        System.out.print("Enter Order ID to update: ");
        int orderId = readInt();
        in.nextLine(); 
        
        System.out.print("Enter new status [ pending | shipped | delivered | cancelled ]: ");
        String newStatus = in.nextLine();

        boolean updated = Order.updateOrderStatus(orders, orderId, newStatus);
        
        if (updated) {
            System.out.println("\nOrder " + orderId + " status updated successfully.");
        }
        
        break;
                    
        case 3:
        
        System.out.print("Enter Order ID to cancel: ");
        int ordId = readInt();

        boolean cancelled = Order.cancelOrder(orders, ordId);
        
        if (cancelled) {
            System.out.println("\nOrder " + ordId + " has been Cancelled successfully.");
        }   
        
        break;
                    
        case 4:
            
        in.nextLine(); 

        System.out.print("Enter first date (dd/MM/yyyy): ");
        String sDate = in.nextLine();

        System.out.print("Enter second date (dd/MM/yyyy): ");
        String eDate = in.nextLine();

        LinkedList<Order> between = Order.allOrdersBetweenDates(orders, sDate, eDate);
        
        if (between.empty()) {
        System.out.println("\nNo orders between " + sDate + " and " + eDate + ".");
        } else {
        System.out.println("\nOrders between " + sDate + " and " + eDate + " displayed successfully.");
             }
        
        break;
     
        case 5:
            
	System.out.println("Back to Main Menu...");
        break;
                    
        default:
            
        System.out.println("Invalid choice!");
        break;
		}
        
            } while(c3 != 5);
        
        break;
      
case 4:
    
    int c4;
    
    do{
        
    System.out.println("\n---------- Review Menu ----------"); 
    System.out.println("1) Add review");
    System.out.println("2) Edit review");
    System.out.println("3) Average rating for a product");
    System.out.println("4) Top-3 products by avg rating");
    System.out.println("5) Back");
    System.out.print("Choice: ");
    c4 = readInt();

        switch (c4) {
            
	case 1: {
            
	int rid = nextReviewId();
	System.out.print("Enter product ID:");
	int pid = readInt();

	if (!Product.exists(products, pid)) { // check if product ID exists in products list
	System.out.println("Product ID not found.");
	break;
		}

	System.out.print("Enter customer ID:");
	int cid = readInt();

	if (!customerExists(cid)) { // check if customer id exists in customers list
	System.out.println("Customer ID not found. Please add the customer first.");
	break;
		}

	if (Review.hasCustomerReviewedProduct(reviews, cid, pid)) {// customer can review a product only
																				// once.
	System.out.println("This customer already reviewed this product. Use 'Edit review' instead.");
	break;
		}

	System.out.print("Enter rating (1-5):");
	int rating = readInt();

	if (!Review.isRatingValid(rating)) {// validates rating
	System.out.println("Invalid rating. Must be 1..5.");
	break;
		}

	System.out.print("Enter comment:");
	in.nextLine();
	String comment = in.nextLine();

	Product p = Product.findProductById(products, pid);
	if (p != null) {
	Review r = new Review(rid, pid, cid, rating, comment);
	reviews.insert(r);
	p.addReview(r);
	System.out.println("Review added.");
	break;
		}
        
	break;
		}
        
	case 2: {
            
	System.out.print("Enter reviewId to edit: ");
	int rid = readInt();

	Review existing = Review.findById(reviews, rid);
	if (existing == null) {
	System.out.println("Review not found.");
	break;
		}

	System.out.print("new rating (1..5): ");
	int newRating = readInt();
	if (!Review.isRatingValid(newRating)) {
	System.out.println("Invalid rating. Must be 1..5.");
	break;
		}

	System.out.print("new comment: ");
	in.nextLine();
	String newComment = in.nextLine();

	boolean ok = Review.updateRatingAndComment(reviews, rid, newRating, newComment);
	System.out.println(ok ? "Review has been updated." : "Update failed.");
        
	break;
        
	}
        
	case 3: {
            
	System.out.print("Enter a productId: ");
	int pid = readInt();

	if (!Product.exists(products, pid)) { // check if product ID exists in products list
	System.out.println("Product ID not found.");
	break;
		}

	Product product = Product.findProductById(products, pid);
	System.out.println("Average rating = " + product.getAverageRating());
        
	break;
        
		}
        
	case 4:
            
	Product.top3ByAverage(products);
	break;
        
         case 5:
            
	System.out.println("Back to Main Menu...");
        break;
        
	default:
            
         System.out.println("Invalid choice!");
	break;
	}
             } while (c4 != 5);
    
	break;
        
	default:
            
        System.out.println("Invalid choice!");
	break;
	}


            } while (choice != 5);

        System.out.println("Goodbye!");
        
	} // End of main

//-------------------------------------

	// Helper methods
	// Small helper to avoid Scanner newline pitfalls

    private static int readInt() {
            
	while (!in.hasNextInt()) {
	in.next();
          }   
	return in.nextInt();
	}
        
        
    private static double readDouble() {
            
        while (!in.hasNextDouble()) {
        in.next();
          }
        return in.nextDouble();
        }
        
        
    private static int nextReviewId() {
	if (reviews.empty())
	return 1;

	int max = 0;
	reviews.findFirst();
	do {
            Review r = reviews.retrieve();
            if (r != null && r.getReviewId() > max) {
            max = r.getReviewId();
		}
            if (reviews.last())
            break;
            reviews.findNext();
		} while (true);

	return max + 1;
	}

        
    private static int nextProductId() {
	if (products.empty())
	return 1;

	int max = 0;
	products.findFirst();
	do {
            Product p = products.retrieve();
            if (p != null && p.getProductId() > max) {
            max = p.getProductId();
		}
            if (products.last())
		break;
            
            products.findNext();
		} while (true);

	return max + 1;
	}

    public static boolean customerExists(int id) {
	if (customers == null || customers.empty())
            return false;

	customers.findFirst();
	do {
	Customers c = customers.retrieve();
	if (c != null && c.getCustomerId() == id)
	return true;
	if (customers.last())
	break;
	customers.findNext();
        	} while (true);

	return false;
	}
        
    private static int nextOrderId() {
        if (orders.empty()) return 1;

        int max = 0;
        orders.findFirst();
        do {
            Order o = orders.retrieve();
            if (o != null && o.getOrderId() > max)
            max = o.getOrderId();

            if (orders.last()) break;
            orders.findNext();
                } while (true);

       return max + 1;
        }


    }// End of class Main
