/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ds1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {
    
    /**
     * Load all initial data from CSV files at application startup
     */
    public static void loadAllData() {
        System.out.println("Loading initial data from CSV files...");
        
        loadProductsCSV("products.csv");
        loadCustomersCSV("customers.csv");
        loadReviewsCSV("reviews.csv");
        loadOrdersCSV("orders.csv");
        
        System.out.println(" All data loaded successfully!");
    }

    // ---- Products CSV Loader ----
    public static void loadProductsCSV(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.toLowerCase().contains("product")) {
                    first = false;
                    continue; // Skip header
                }
                String[] data = line.split(",", -1);
                if (data.length < 4) continue;
                
                int id = Integer.parseInt(data[0].trim());
                String name = data[1].trim();
                double price = Double.parseDouble(data[2].trim());
                int stock = Integer.parseInt(data[3].trim());

               
                Main.products.insertAtEnd(new Product(id, name, price, stock));
                
               
            }
            System.out.println("Products data loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error reading products CSV: " + e.getMessage());
        } 
    }

    // ---- Reviews CSV Loader ----
    public static void loadReviewsCSV(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.toLowerCase().contains("review")) {
                    first = false;
                    continue; // Skip header
                }
                String[] data = line.split(",", -1);
                if (data.length < 5) continue;
                
                int rid = Integer.parseInt(data[0].trim());
                int pid = Integer.parseInt(data[1].trim());
                int cid = Integer.parseInt(data[2].trim());
                int rate = Integer.parseInt(data[3].trim());
                String comment = data[4].trim();

               
                Main.reviews.insertAtEnd(new Review(rid, pid, cid, rate, comment));
                
            }
            System.out.println("Reviews data loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error reading reviews CSV: " + e.getMessage());
        } 
    }

    // ---- Customers CSV Loader ----
    public static void loadCustomersCSV(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.toLowerCase().contains("customer")) {
                    first = false;
                    continue; // Skip header
                }
                String[] data = line.split(",", -1);
                if (data.length < 3) continue;
                
                int customerId = Integer.parseInt(data[0].trim());
                String name = data[1].trim();
                String email = data[2].trim();
                
                Customers c = new Customers(customerId, name, email);
                
                
                Main.customers.insertAtEnd(c);
                
                
            }
            System.out.println(" Customers data loaded successfully!");
        } catch (IOException e) {
            System.out.println("Error reading customers CSV: " + e.getMessage());
        }
    }

    // ---- Order CSV Loader ----
    public static void loadOrdersCSV(String path) {
    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
        String line;
        boolean first = true;

        while ((line = br.readLine()) != null) {
            if (first) {
                if (line.toLowerCase().contains("order")) {
                    first = false;
                    continue;
                }
                first = false;
            }

            if (line.trim().isEmpty()) continue;

            String[] data = line.split(",", -1);
            if (data.length < 6) continue;

            int orderId = Integer.parseInt(data[0].trim());
            int customerId = Integer.parseInt(data[1].trim());

            String products = data[2].trim();
            products = products.replace("\"", "");       
            String[] pTokens = products.split(";");
            Integer[] productIds = new Integer[pTokens.length];
            for (int i = 0; i < pTokens.length; i++) {
                productIds[i] = Integer.parseInt(pTokens[i].trim());
            }

            double totalPrice = Double.parseDouble(data[3].trim());

            String cvsDate = data[4].trim();
            String date;
            try {
                java.time.format.DateTimeFormatter f = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
                java.time.LocalDate d = java.time.LocalDate.parse(cvsDate, f);
                date = d.toString(); 
            } catch (Exception e) {
                date = cvsDate;
            }

            String status = data[5].trim();

            Order o = new Order(orderId, customerId, productIds, totalPrice, date, status);

            Main.orders.insertAtEnd(o);
            
            Customers c = Customers.findCustomerById(customerId);
            if (c != null) {
                c.getOrdersList().insert(o);
            }

        }

        System.out.println("Orders data loaded successfully!");
    } catch (IOException e) {
        System.out.println("Error reading orders CSV: " + e.getMessage());
    }
}
}
   
